<?php

require './vendor/autoload.php';
error_reporting(E_ALL);
ini_set("display_errors", 1);

$params = array(
    'credentials' => array(
        'key' => 'AKIARGQDAINQCIPUAXXC',
        'secret' => 'pXEzGOpNhRGha2qCsInR5dailKOabZUn+qVKkr8C',
    ),
    'region' => 'us-east-1', // < your aws from SNS Topic region
    'version' => 'latest'
);
$sns = new \Aws\Sns\SnsClient($params);

$args = array(
    "MessageAttributes" => [
                'AWS.SNS.SMS.SenderID' => [
                    'DataType' => 'String',
                    'StringValue' => '305amazon'
                ],
                'AWS.SNS.SMS.SMSType' => [
                    'DataType' => 'String',
                    'StringValue' => 'Promotional'
                ]
            ],
    "Message" => "Hello World! Visit www.tiagogouvea.com.br!",
    "PhoneNumber" => "+17863342521"
);


$result = $sns->publish($args);
echo "<pre>";
var_dump($result);
echo "</pre>";

?>